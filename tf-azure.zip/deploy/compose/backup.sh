echo "No backups are made on staging"
