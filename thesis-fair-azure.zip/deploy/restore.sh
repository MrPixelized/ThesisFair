mongorestore --drop mongodb://$1:27017 initDB/
